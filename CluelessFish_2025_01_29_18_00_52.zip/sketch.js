function setup() {
  createCanvas(500, 500)
  background(100,200,255);
}

function draw() {
  fill("magenta");
  stroke("black");
  triangle(230,200,280,150,280,250);
  ellipse(200,200, 100, 70);
  
  fill(255, 150, 255);
  triangle(200,200,220,220,230,210);
  fill('white')
  ellipse (170,190,15,15)
  fill('black')
  ellipse(170,190,10,10)
  line (155,210,160,211)
  
  fill("white")
  noStroke()
  ellipse (100,100,100,50)
  triangle(120,120,130,100,170,160)
  fill('black')
  text("Water?",80,105)
  
  fill(194, 178, 128);
  noStroke();
  rect(0,400,500,100);

}