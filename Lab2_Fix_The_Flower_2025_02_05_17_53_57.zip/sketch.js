function setup() {
  createCanvas(400, 400);
  background("skyblue")
}
function draw(){
  noFill();
  noStroke();
  
  //OBJECTS
  var cloudOne = {
    x: 50,
    y: 50,
    diameter: 50
  }
  var cloudTwo = {
    x: 260,
    y: 80,
    diameter: 50
  }
  var stem = {
    x:190,
    y:200,
    width:20,
    length:180
  }
  var leftPetal = {
    x:150,
    y:200,
    width:80,
    length:50
  }
  var rightPetal = {
    x:250,
    y:200,
    width:80,
    length:50
  }
  var topPetal = {
    x:200,
    y:150,
    width:50,
    length:80
  }
  var bottomPetal = {
    x:200,
    y:250,
    width:50,
    length:80
  }
  var centerFlower = {
    x:200,
    y:200,
    diameter:40
  }
  var ground = {
    x:0,
    y:350,
    width:400,
    length:50
  }
  //ground
  fill(19,109,21)
  rect(ground.x,ground.y,ground.width,ground.length)
  
  //stem
  fill(65,152,10)
  rect(stem.x,stem.y,stem.width,stem.length)
  
  // petals
  fill(255,255,0)
  ellipse(leftPetal.x,leftPetal.y,leftPetal.width,leftPetal.length);
  fill(255,205,0)
  ellipse(rightPetal.x,rightPetal.y,rightPetal.width,rightPetal.length);
  fill(255,155,0)
  ellipse(topPetal.x,topPetal.y,topPetal.width,topPetal.length);
  fill(255,105,0)
  ellipse(bottomPetal.x,bottomPetal.y,bottomPetal.width,bottomPetal.length);

  //center of flower
  fill(255,55,0)
  ellipse(centerFlower.x,centerFlower.y,centerFlower.diameter);
  
  //cloud_one
  fill("white")
  ellipse(cloudOne.x,cloudOne.y,cloudOne.diameter)
  ellipse(cloudOne.x+15,cloudOne.y-30,cloudOne.diameter)
  ellipse(cloudOne.x+30,cloudOne.y,cloudOne.diameter)
  ellipse(cloudOne.x+30,cloudOne.y-30,cloudOne.diameter)
  ellipse(cloudOne.x+50,cloudOne.y-15,cloudOne.diameter)
  
  //cloud_two
  ellipse(cloudTwo.x,cloudTwo.y,cloudTwo.diameter)
  ellipse(cloudTwo.x+10,cloudTwo.y-30,cloudTwo.diameter)
  ellipse(cloudTwo.x+22,cloudTwo.y,cloudTwo.diameter)
  ellipse(cloudTwo.x+30,cloudTwo.y-30,cloudTwo.diameter)
  ellipse(cloudTwo.x+50,cloudTwo.y-15,cloudTwo.diameter)
  
}
